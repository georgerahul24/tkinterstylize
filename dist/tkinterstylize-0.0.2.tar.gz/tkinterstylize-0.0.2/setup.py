from setuptools import setup

setup(
    name='tkinterstylize',
    version='0.0.2',
    packages=['tkinterstylize'],
    url='',
    license='MIT',
    author='GR',
    author_email='georgerahul24@gmail.com',
    description='Stylize Tkinter'
)
