from setuptools import setup

setup(
    name='tkinterstylize',
    version='0.0.5',
    packages=['tkinterstylize'],
    url='https://github.com/georgerahul24/tkinterstylize',
    license='MIT',
    author='GR',
    author_email='georgerahul24@gmail.com',
    description='Stylize Tkinter'
)
